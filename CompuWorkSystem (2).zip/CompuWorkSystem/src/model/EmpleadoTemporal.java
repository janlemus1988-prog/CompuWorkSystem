package model;

public class EmpleadoTemporal extends Empleado {
    private int duracionContrato; // en meses
    private String agencia;

    public EmpleadoTemporal(String nombre, String cedula, String cargo, int duracionContrato, String agencia) {
        super(nombre, cedula, cargo);
        this.duracionContrato = duracionContrato;
        this.agencia = agencia;
    }

    @Override
    public void calcularDesempeño() {
        System.out.println("Desempeño calculado para empleado temporal.");
    }

    // Getters y Setters
    public int getDuracionContrato() { return duracionContrato; }
    public void setDuracionContrato(int duracionContrato) { this.duracionContrato = duracionContrato; }

    public String getAgencia() { return agencia; }
    public void setAgencia(String agencia) { this.agencia = agencia; }
}