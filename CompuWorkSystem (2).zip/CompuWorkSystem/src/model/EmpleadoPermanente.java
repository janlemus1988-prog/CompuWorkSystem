package model;

public class EmpleadoPermanente extends Empleado {
    private double salario;
    private String beneficios;

    public EmpleadoPermanente(String nombre, String cedula, String cargo, double salario, String beneficios) {
        super(nombre, cedula, cargo);
        this.salario = salario;
        this.beneficios = beneficios;
    }

    @Override
    public void calcularDesempeño() {
        System.out.println("Desempeño calculado para empleado permanente.");
    }
}
