package model;

import java.util.Date;

public class ReporteDesempeño {
    private Date fecha;
    private double puntuacion;
    private String comentarios;

    public ReporteDesempeño(Date fecha, double puntuacion, String comentarios) {
        this.fecha = fecha;
        this.puntuacion = puntuacion;
        this.comentarios = comentarios;
    }

    public ReporteDesempeño(String comentario, String fecha, Empleado empleado) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Métodos
    public void generarReporte() {
        System.out.println("Generando reporte de desempeño...");
    }

    public String mostrarReporte() {
        return "Fecha: " + fecha + " | Puntuación: " + puntuacion + " | Comentarios: " + comentarios;
    }

    // Getters y Setters
    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public double getPuntuacion() { return puntuacion; }
    public void setPuntuacion(double puntuacion) { this.puntuacion = puntuacion; }

    public String getComentarios() { return comentarios; }
    public void setComentarios(String comentarios) { this.comentarios = comentarios; }
}
