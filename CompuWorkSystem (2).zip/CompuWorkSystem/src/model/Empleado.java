package model;

public class Empleado {
    private String nombre;
    private String cedula;
    private String cargo;

    public Empleado(String nombre, String cedula, String cargo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.cargo = cargo;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = cargo; }

    // Método polimórfico
    public void calcularDesempeño() {
        System.out.println("Calculando desempeño genérico...");
    }
}