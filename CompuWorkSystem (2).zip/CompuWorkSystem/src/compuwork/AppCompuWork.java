package compuwork;

import java.util.Scanner;
import model.Departamento;
import model.Empleado;
import model.ReporteDesempeño;
import service.DepartamentoService;
import service.EmpleadoService;
import service.ReporteService;

public class AppCompuWork {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmpleadoService empleadoService = new EmpleadoService();
        DepartamentoService departamentoService = new DepartamentoService();
        ReporteService reporteService = new ReporteService();

        int opcion;
        do {
            System.out.println("\n=== Menú CompuWork ===");
            System.out.println("1. Registrar empleado");
            System.out.println("2. Crear departamento");
            System.out.println("3. Generar reporte de desempeño");
            System.out.println("4. Mostrar todos los reportes");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> {
                    System.out.print("ID del empleado: ");
                    String id = sc.nextLine();
                    System.out.print("Nombre del empleado: ");
                    String nombre = sc.nextLine();
                    System.out.print("Departamento: ");
                    String depto = sc.nextLine();
                    Empleado emp = new Empleado(id, nombre, depto);
                    empleadoService.agregarEmpleado(emp);
                    System.out.println("Empleado registrado.");
                }

                case 2 -> {
                    System.out.print("Código del departamento: ");
                    String cod = sc.nextLine();
                    System.out.print("Nombre del departamento: ");
                    String nomDepto = sc.nextLine();
                    Departamento d = new Departamento(cod, nomDepto);
                    departamentoService.agregarDepartamento(d);
                    System.out.println("Departamento creado.");
                }

                case 3 -> {
                    System.out.print("ID del empleado para el reporte: ");
                    String idReporte = sc.nextLine();
                    Empleado empleado = empleadoService.buscarPorId(idReporte);
                    if (empleado != null) {
                        System.out.print("Comentario de desempeño: ");
                        String comentario = sc.nextLine();
                        System.out.print("Fecha (YYYY-MM-DD): ");
                        String fecha = sc.nextLine();
                        ReporteDesempeño r = new ReporteDesempeño(comentario, fecha, empleado);
                        reporteService.agregarReporte(r);
                        System.out.println("Reporte generado.");
                    } else {
                        System.out.println("Empleado no encontrado.");
                    }
                }

                case 4 -> reporteService.mostrarReportes();

                case 0 -> System.out.println("Saliendo del sistema...");

                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }
}
