package service;

import model.Empleado;
import model.ReporteDesempeño;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReporteService {
    private List<ReporteDesempeño> reportes = new ArrayList<>();

    // Generar reporte individual
    public void generarReporteEmpleado(Empleado e, double puntuacion, String comentarios) {
        ReporteDesempeño reporte = new ReporteDesempeño(new Date(), puntuacion, comentarios);
        reportes.add(reporte);
        System.out.println("Reporte generado para: " + e.getNombre());
    }

    // Mostrar todos los reportes
    public void mostrarReportes() {
        for (ReporteDesempeño r : reportes) {
            System.out.println(r.mostrarReporte());
        }
    }

    // Reportes por empleado (filtrado)
    public List<ReporteDesempeño> obtenerReportesPorEmpleado(Empleado e) {
        List<ReporteDesempeño> resultado = new ArrayList<>();
        for (ReporteDesempeño r : reportes) {
            if (r.getComentarios().contains(e.getNombre())) { 
                resultado.add(r);
            }
        }
        return resultado;
    }

    public void agregarReporte(ReporteDesempeño r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
