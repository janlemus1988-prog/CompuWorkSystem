package service;

import model.Empleado;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoService {
    private List<Empleado> empleados = new ArrayList<>();

    public void agregarEmpleado(Empleado e) {
        empleados.add(e);
    }

    public void eliminarEmpleado(Empleado e) {
        empleados.remove(e);
    }

    public List<Empleado> listarEmpleados() {
        return empleados;
    }

    public Empleado buscarPorId(String idReporte) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
