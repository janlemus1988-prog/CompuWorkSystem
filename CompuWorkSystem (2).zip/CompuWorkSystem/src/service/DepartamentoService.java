package service;

import model.Departamento;
import model.Empleado;
import java.util.ArrayList;
import java.util.List;

public class DepartamentoService {
    private List<Departamento> departamentos = new ArrayList<>();

    // Crear
    public void agregarDepartamento(Departamento d) {
        departamentos.add(d);
    }

    // Eliminar
    public void eliminarDepartamento(Departamento d) {
        departamentos.remove(d);
    }

    // Listar
    public List<Departamento> listarDepartamentos() {
        return departamentos;
    }

    // Asignar empleado a un departamento
    public void asignarEmpleado(Departamento d, Empleado e) {
        d.agregarEmpleado(e);
    }

    // Mostrar empleados de un departamento
    public List<Empleado> listarEmpleadosPorDepartamento(Departamento d) {
        return d.listarEmpleados();
    }
}
