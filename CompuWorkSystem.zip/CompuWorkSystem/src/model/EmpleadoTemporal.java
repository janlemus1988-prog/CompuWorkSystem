/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package compuworksystem;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author 1
 */
public class CompuWorkSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
package model;

public class Empleado {
    private String nombre;
    private String cedula;
    private String cargo;

    public Empleado(String nombre, String cedula, String cargo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.cargo = cargo;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = cargo; }

    // Método polimórfico
    public void calcularDesempeño() {
        System.out.println("Calculando desempeño genérico...");
    }
}
package model;

public class EmpleadoPermanente extends Empleado {
    private double salario;
    private String beneficios;

    public EmpleadoPermanente(String nombre, String cedula, String cargo, double salario, String beneficios) {
        super(nombre, cedula, cargo);
        this.salario = salario;
        this.beneficios = beneficios;
    }

    @Override
    public void calcularDesempeño() {
        System.out.println("Desempeño calculado para empleado permanente.");
    }
}
package model;

public class EmpleadoTemporal extends Empleado {
    private int duracionContrato; // en meses
    private String agencia;

    public EmpleadoTemporal(String nombre, String cedula, String cargo, int duracionContrato, String agencia) {
        super(nombre, cedula, cargo);
        this.duracionContrato = duracionContrato;
        this.agencia = agencia;
    }

    @Override
    public void calcularDesempeño() {
        System.out.println("Desempeño calculado para empleado temporal.");
    }

    // Getters y Setters
    public int getDuracionContrato() { return duracionContrato; }
    public void setDuracionContrato(int duracionContrato) { this.duracionContrato = duracionContrato; }

    public String getAgencia() { return agencia; }
    public void setAgencia(String agencia) { this.agencia = agencia; }
}
package model;

import java.util.ArrayList;
import java.util.List;

public class Departamento {
    private String nombre;
    private String codigo;
    private List<Empleado> empleados;

    public Departamento(String nombre, String codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.empleados = new ArrayList<>();
    }

    // Métodos
    public void agregarEmpleado(Empleado e) {
        empleados.add(e);
    }

    public void eliminarEmpleado(Empleado e) {
        empleados.remove(e);
    }

    public List<Empleado> listarEmpleados() {
        return empleados;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
}
package model;

import java.util.Date;

public class ReporteDesempeño {
    private Date fecha;
    private double puntuacion;
    private String comentarios;

    public ReporteDesempeño(Date fecha, double puntuacion, String comentarios) {
        this.fecha = fecha;
        this.puntuacion = puntuacion;
        this.comentarios = comentarios;
    }

    // Métodos
    public void generarReporte() {
        System.out.println("Generando reporte de desempeño...");
    }

    public String mostrarReporte() {
        return "Fecha: " + fecha + " | Puntuación: " + puntuacion + " | Comentarios: " + comentarios;
    }

    // Getters y Setters
    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public double getPuntuacion() { return puntuacion; }
    public void setPuntuacion(double puntuacion) { this.puntuacion = puntuacion; }

    public String getComentarios() { return comentarios; }
    public void setComentarios(String comentarios) { this.comentarios = comentarios; }
}
package service;

import model.Departamento;
import model.Empleado;
import java.util.ArrayList;
import java.util.List;

public class DepartamentoService {
    private List<Departamento> departamentos = new ArrayList<>();

    // Crear
    public void agregarDepartamento(Departamento d) {
        departamentos.add(d);
    }

    // Eliminar
    public void eliminarDepartamento(Departamento d) {
        departamentos.remove(d);
    }

    // Listar
    public List<Departamento> listarDepartamentos() {
        return departamentos;
    }

    // Asignar empleado a un departamento
    public void asignarEmpleado(Departamento d, Empleado e) {
        d.agregarEmpleado(e);
    }

    // Mostrar empleados de un departamento
    public List<Empleado> listarEmpleadosPorDepartamento(Departamento d) {
        return d.listarEmpleados();
    }
}
package service;

import model.Empleado;
import model.ReporteDesempeño;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReporteService {
    private List<ReporteDesempeño> reportes = new ArrayList<>();

    // Generar reporte individual
    public void generarReporteEmpleado(Empleado e, double puntuacion, String comentarios) {
        ReporteDesempeño reporte = new ReporteDesempeño(new Date(), puntuacion, comentarios);
        reportes.add(reporte);
        System.out.println("Reporte generado para: " + e.getNombre());
    }

    // Mostrar todos los reportes
    public void mostrarReportes() {
        for (ReporteDesempeño r : reportes) {
            System.out.println(r.mostrarReporte());
        }
    }

    // Reportes por empleado (filtrado)
    public List<ReporteDesempeño> obtenerReportesPorEmpleado(Empleado e) {
        List<ReporteDesempeño> resultado = new ArrayList<>();
        for (ReporteDesempeño r : reportes) {
            if (r.getComentarios().contains(e.getNombre())) { 
                resultado.add(r);
            }
        }
        return resultado;
    }
}

